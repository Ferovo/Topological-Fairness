from implementations.utils import load_bail, load_income, load_pokec_renewed
from numpy import *
from implementations.approximator import grad_z_graph, s_test_graph_cost, cal_influence_edge, cal_influence_on_node, cal_influence_graph
import numpy as np
import scipy.sparse as sp
import torch
from tqdm import tqdm
import pandas as pd
from scipy.spatial import distance_matrix
import os
import networkx as nx
import time
import argparse
from torch_geometric.utils import convert
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')
import ctypes



ctypes.cdll.LoadLibrary('caffe2_nvrtc.dll')
torch.backends.cudnn.benchmark = True

parser = argparse.ArgumentParser()
parser.add_argument('--dataset', type=str, default="income", help='One dataset from income, bail, pokec1, and pokec2.')
parser.add_argument('--seed', type=int, default=10, help='Random seed.')
args = parser.parse_args()

dataset_name = args.dataset
np.random.seed(args.seed)
torch.manual_seed(args.seed)
torch.cuda.manual_seed(args.seed)

def find123Nei(G, node):
    nodes = list(nx.nodes(G))
    nei1_li = []
    nei2_li = []
    nei3_li = []
    for FNs in list(nx.neighbors(G, node)):
        nei1_li .append(FNs)

    for n1 in nei1_li:
        for SNs in list(nx.neighbors(G, n1)):
            nei2_li.append(SNs)
    nei2_li = list(set(nei2_li) - set(nei1_li))
    if node in nei2_li:
        nei2_li.remove(node)

    for n2 in nei2_li:
        for TNs in nx.neighbors(G, n2):
            nei3_li.append(TNs)
    nei3_li = list(set(nei3_li) - set(nei2_li) - set(nei1_li))
    if node in nei3_li:
        nei3_li.remove(node)

    return nei1_li, nei2_li, nei3_li

def feature_norm(features):
    min_values = features.min(axis=0)[0]
    max_values = features.max(axis=0)[0]
    return 2*(features - min_values).div(max_values-min_values) - 1

def build_relationship(x, thresh=0.25):
    df_euclid = pd.DataFrame(1 / (1 + distance_matrix(x.T.T, x.T.T)), columns=x.T.columns, index=x.T.columns)
    df_euclid = df_euclid.to_numpy()
    idx_map = []
    for ind in range(df_euclid.shape[0]):
        max_sim = np.sort(df_euclid[ind, :])[-2]
        neig_id = np.where(df_euclid[ind, :] > thresh * max_sim)[0]
        import random
        random.seed(912)
        random.shuffle(neig_id)
        for neig in neig_id:
            if neig != ind:
                idx_map.append([ind, neig])
    idx_map = np.array(idx_map)

    return idx_map

def get_adj(dataset_name):
    predict_attr = "RECID"
    if dataset_name == 'bail':
        predict_attr="RECID"
    elif dataset_name == 'income':
        predict_attr = "income"

    if dataset_name == 'pokec1' or dataset_name == 'pokec2':
        if dataset_name == 'pokec1':
            edges = np.load('../data/pokec_dataset/region_job_1_edges.npy')
            labels = np.load('../data/pokec_dataset/region_job_1_labels.npy')
        else:
            edges = np.load('../data/pokec_dataset/region_job_2_2_edges.npy')
            labels = np.load('../data/pokec_dataset/region_job_2_2_labels.npy')
        edges_unordered = [[edges[0][i], edges[1][i]] for i in range(edges.shape[1])]
        idx_train_set = set(idx_train_vanilla.tolist())
        train_edges = []
        for edge in edges_unordered:
            endpoint1, endpoint2 = edge
            edge_tuple = (endpoint1, endpoint2)
            if endpoint1 in idx_train_set and endpoint2 in idx_train_set and edge_tuple not in train_edges:
                train_edges.append(edge_tuple)

        adj = sp.coo_matrix((np.ones(edges.shape[0]), (edges[:, 0], edges[:, 1])),
                            shape=(labels.shape[0], labels.shape[0]),
                            dtype=np.float32)
        adj = adj + adj.T.multiply(adj.T > adj) - adj.multiply(adj.T > adj)
        return adj, train_edges

    path="../data/" + str(dataset_name) + "/"
    dataset = dataset_name
    print('Reconstructing the adj of {} dataset...'.format(dataset))

    idx_features_labels = pd.read_csv(os.path.join(path, "{}.csv".format(dataset)))

    node_features = [None] * len(idx_features_labels)
    for node_idx in range(len(idx_features_labels)):
        features_of_node = idx_features_labels.loc[node_idx].values[0:].astype(int)
        # print(features_of_node)
        node_features[node_idx] = features_of_node
        # print(node_features[0])

    header = list(idx_features_labels.columns)
    header.remove(predict_attr)

    if os.path.exists(f'{path}/{dataset}_edges.txt'):
        edges_unordered = np.genfromtxt(f'{path}/{dataset}_edges.txt').astype('int')
    else:
        edges_unordered = build_relationship(idx_features_labels[header], thresh=0.6)
        np.savetxt(f'{path}/{dataset}_edges.txt', edges_unordered)


    features = sp.csr_matrix(idx_features_labels[header], dtype=np.float32)
    labels = idx_features_labels[predict_attr].values
    idx_node = np.arange(features.shape[0])
    idx_map = {j: i for i, j in enumerate(idx_node)}
    edges = np.array(list(map(idx_map.get, edges_unordered.flatten())),
                     dtype=int).reshape(edges_unordered.shape)
    idx_edge = list(range(len(edges_unordered)))

    idx_train_set = set(idx_train_vanilla.tolist())

    train_edges = []
    for edge in edges_unordered:
        endpoint1, endpoint2 = edge
        edge_tuple = (endpoint1, endpoint2)
        if endpoint1 in idx_train_set and endpoint2 in idx_train_set and edge_tuple not in train_edges:
            train_edges.append(edge_tuple)

    idx_val_set = set(idx_val_vanilla.tolist())

    val_edges = []
    for edge in edges_unordered:
        endpoint1, endpoint2 = edge
        if endpoint1 in idx_val_set and endpoint2 in idx_val_set and [endpoint1, endpoint2] not in val_edges:
            val_edges.append([endpoint1, endpoint2])

    idx_test_set = set(idx_test_vanilla.tolist())

    test_edges = []
    for edge in edges_unordered:
        endpoint1, endpoint2 = edge
        if endpoint1 in idx_test_set and endpoint2 in idx_test_set and [endpoint1, endpoint2] not in test_edges:
            test_edges.append([endpoint1, endpoint2])

    adj = sp.coo_matrix((np.ones(edges.shape[0]), (edges[:, 0], edges[:, 1])),
                        shape=(labels.shape[0], labels.shape[0]),
                        dtype=np.float32)
    adj = adj + adj.T.multiply(adj.T > adj) - adj.multiply(adj.T > adj)

    return adj, train_edges

def del_adj(harmful_edges):
    adj = adj_vanilla.copy()
    adj_coo = adj.tocoo()
    rows, cols = adj_coo.row, adj_coo.col

    mask = np.ones_like(rows, dtype=bool)
    for i, j in harmful_edges:
        mask = np.logical_and(mask, np.logical_not(np.logical_and(rows == i, cols == j)))
        mask = np.logical_and(mask, np.logical_not(np.logical_and(rows == j, cols == i)))

    modified_adj_coo = sp.coo_matrix((adj_coo.data[mask], (rows[mask], cols[mask])), shape=adj_coo.shape)

    adj = modified_adj_coo.tocsr()

    return adj


if dataset_name == 'bail':
    model = torch.load('gcn_' + dataset_name + '.pth')
    adj_vanilla, features_vanilla, labels_vanilla, idx_train_vanilla, idx_val_vanilla, idx_test_vanilla, sens_vanilla = load_bail('bail')
    norm_features = feature_norm(features_vanilla)
    norm_features[:, 0] = features_vanilla[:, 0]
    features_vanilla = norm_features
elif dataset_name == 'income':
    model = torch.load('gcn_' + dataset_name + '.pth')
    adj_vanilla, features_vanilla, labels_vanilla, idx_train_vanilla, idx_val_vanilla, idx_test_vanilla, sens_vanilla = load_income('income')
    norm_features = feature_norm(features_vanilla)
    norm_features[:, 8] = features_vanilla[:, 8]
    features_vanilla = norm_features
elif dataset_name == 'pokec1':
    model = torch.load('gcn_' + dataset_name + '.pth')
    adj_vanilla, features_vanilla, labels_vanilla, idx_train_vanilla, idx_val_vanilla, idx_test_vanilla, sens_vanilla = load_pokec_renewed(1)
elif dataset_name == 'pokec2':
    model = torch.load('gcn_' + dataset_name + '.pth')
    adj_vanilla, features_vanilla, labels_vanilla, idx_train_vanilla, idx_val_vanilla, idx_test_vanilla, sens_vanilla = load_pokec_renewed(2)

edge_index = convert.from_scipy_sparse_matrix(adj_vanilla)[0]

print("Pre-processing data...")
computation_graph_involving = []
the_adj, train_edges = get_adj(dataset_name)
hop = 1
G = nx.Graph(the_adj)

edges = []
for i in tqdm(range(idx_train_vanilla.shape[0])):
    neighbors = find123Nei(G, idx_train_vanilla[i].item())
    mid = []
    for j in range(hop):
        mid += neighbors[j]
    mid = list(set(mid).intersection(set(idx_train_vanilla.numpy().tolist())))
    computation_graph_involving.append(mid)


print("Pre-processing completed.")

time1 = time.time()

h_estimate_cost = s_test_graph_cost(edge_index, features_vanilla, idx_train_vanilla, idx_test_vanilla, labels_vanilla, sens_vanilla, model, gpu=0)
gradients_list = grad_z_graph(edge_index, features_vanilla, idx_train_vanilla, labels_vanilla, model, gpu=0)
influence = cal_influence_graph(idx_train_vanilla, h_estimate_cost, gradients_list, gpu=0)
edge_influences, harmful_edges, helpful_edges , harmful_edges_train, helpful_edges_train = cal_influence_edge(features_vanilla, train_edges, idx_train_vanilla, h_estimate_cost, gradients_list, gpu=0)

non_iid_influence = []

for i in tqdm(range(idx_train_vanilla.shape[0])):

    if len(computation_graph_involving[i]) == 0:
        non_iid_influence.append(0)
        continue

    reference = list(range(adj_vanilla.shape[0]))

    idx_train = idx_train_vanilla.clone()
    idx_val = idx_val_vanilla.clone()
    idx_test = idx_test_vanilla.clone()

    idx_train = torch.LongTensor(np.array(reference)[idx_train.numpy()])
    idx_val = torch.LongTensor(np.array(reference)[idx_val.numpy()])
    idx_test = torch.LongTensor(np.array(reference)[idx_test.numpy()])

    computation_graph_involving_copy = computation_graph_involving.copy()
    for j in range(len(computation_graph_involving_copy)):
        computation_graph_involving_copy[j] = np.array(reference)[computation_graph_involving_copy[j]]


    features = features_vanilla.clone()
    labels = labels_vanilla.clone()
    sens = sens_vanilla.clone()

    adj = del_adj(harmful_edges)

    edge_index = convert.from_scipy_sparse_matrix(adj)[0]
    h_estimate_cost_node = h_estimate_cost.copy()
    gradients_list_node = grad_z_graph(edge_index, features, torch.LongTensor(computation_graph_involving_copy[i]), labels, model, gpu=0)
    influence_on_node = cal_influence_on_node(idx_train, torch.LongTensor(computation_graph_involving_copy[i]), h_estimate_cost_node, gradients_list_node,
                                                                                gpu=0)
    non_iid_influence.append(sum(influence_on_node))
    influence.append(influence_on_node)
final_influence = []
for i in range(len(non_iid_influence)):
    ref = [idx_train_vanilla.numpy().tolist().index(item) for item in (computation_graph_involving[i] + [idx_train_vanilla[i]])]
    final_influence.append(non_iid_influence[i] - np.array(influence)[ref].sum())

time4 = time.time()
print("Average time per training node:", (time4 - time1)/1000, "s")
np.save('final_influence_' + dataset_name + '.npy', np.array(edge_influences))
# NOTICE: here the helpfulness means the helpfulness to UNFAIRNESS
# print("Helpfulness : ")
# print(final_influence)
