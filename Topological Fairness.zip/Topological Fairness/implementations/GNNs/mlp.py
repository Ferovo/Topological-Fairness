import torch
import torch.nn as nn

class MLP_Body(nn.Module):
    def __init__(self, nfeat, nhid, dropout):
        super(MLP_Body, self).__init__()
        self.fc1 = nn.Linear(nfeat, nhid)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        x = self.fc1(x)
        x = self.relu(x)
        x = self.dropout(x)
        return x

class MLP(nn.Module):
    def __init__(self, nfeat, nhid, nclass, dropout):
        super(MLP, self).__init__()
        self.body = MLP_Body(nfeat, nhid, dropout)
        self.fc = nn.Linear(nhid, 1)  # 修改为输出一个logit值

        for m in self.modules():
            self.weights_init(m)

    def weights_init(self, m):
        if isinstance(m, nn.Linear):
            torch.nn.init.xavier_uniform_(m.weight.data)
            if m.bias is not None:
                m.bias.data.fill_(0.0)

    def forward(self, x):
        x = self.body(x)
        x = self.fc(x)
        return x
