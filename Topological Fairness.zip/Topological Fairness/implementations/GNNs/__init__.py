from .gcn import GCN, GCN_Body
from .gin import GIN
from .mlp import MLP, MLP_Body
